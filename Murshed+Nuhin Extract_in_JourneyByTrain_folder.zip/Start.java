import Classes.*;

import java.lang.*;

public class Start
{
	public static void main(String[] args)
	{
		Welcome welcomeFrame = new Welcome();
		welcomeFrame.setVisible(true);
	}
}