package Classes;

import Classes.*;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;


public abstract class Tickets extends JFrame
{
	private UserAccount user;

	protected String userName;
	protected String ticketFile;
	protected String balanceFile;
	protected String currentBalance;
	protected String ticketPirce = "0";


	
    protected JPanel panel;
	protected ImageIcon bgImage;
    protected JLabel bgLabel, balanceLabel, price, title, from, to, date, time, Choose_a_Class;
    protected JTextField dateTF;
    protected JButton buyBtn, resetBtn, backBtn;
	protected JComboBox des1, des2, timeBox, classBox;
	protected Color bgColor, btnColor, backBtnColor;
	protected Font font1,font2,font3,font4,font5,font6,font7;

    public Tickets(UserAccount user)
    {
        super("Tickets");
        this.setSize(1080,720);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(bgColor);

		this.user = user;
		userName = user.getUserName();
		ticketFile = user.getTicketFile();
		balanceFile = user.getBalanceFile();
		currentBalance = user.getCurrentBalance();


		// Colors
		bgColor = new Color(251,251,251);
		btnColor = new Color(36,138,192);
		backBtnColor = new Color(189,1,1);

		// Fonts
        font1 = new Font("Segoe UI Black", Font.BOLD, 40);
        font2 = new Font("Segoe UI Black", Font.PLAIN, 25);
        font3 = new Font("Segoe UI Black", Font.PLAIN, 20);
        font4 = new Font("Segoe UI Semibold", Font.PLAIN, 35);
        font5 = new Font("Segoe UI Black", Font.BOLD, 25);
        font6 = new Font("Segoe UI", Font.PLAIN, 22);
        font7 = new Font("Segoe UI", Font.PLAIN, 18);
        
		
		bgImage = new ImageIcon("E:/JavaCodes/JourneyByTrain/Images/ticket.PNG");
		bgLabel = new JLabel("",bgImage,JLabel.CENTER);
		bgLabel.setBounds(0, 0, 400, 650);
		panel.add(bgLabel);

        title = new JLabel("Fill-up Ticket Details");
		title.setFont(font1);
        title.setBounds(340,50,700,100);
        panel.add(title);
		
		balanceLabel = new JLabel("Current Balance : " + currentBalance);
        balanceLabel.setBounds(70,530,400,100);
		balanceLabel.setFont(font5);
        panel.add(balanceLabel);


		String[] destinationTable = {"Dhaka", "Rajshahi", "Sylhet", "Khulna", "Barisal", "Rangpur", "Chittagong", "Mymensingh"};

        from = new JLabel("From");
        from.setBounds(450,200,200,50);
		from.setFont(font5);
        panel.add(from);
		
		des1 = new JComboBox(destinationTable);
		des1.setSelectedIndex(-1);
		des1.setBounds(650,200,140,50);
		des1.setFont(font7);
		panel.add(des1);
		
		to = new JLabel("To");
        to.setBounds(810,201,50,50);
		to.setFont(font5);
        panel.add(to);
		
		des2 = new JComboBox(destinationTable);
		des2.setSelectedIndex(-1);
		des2.setBounds(860,200,140,50);
		des2.setFont(font7);
		panel.add(des2);
		

        date = new JLabel("Date");
        date.setBounds(450,270,200,50);
        date.setFont(font5);
		panel.add(date);
		
		dateTF = new JTextField();
        dateTF.setText("DD/MM/YY");
        dateTF.setBounds(650,270,140,50);
		dateTF.setFont(font6);
        panel.add(dateTF);
		
		String[] timeTable = {"8:00 AM", "10:00 AM", "12:00 PM", "2:00 PM", "4:00 PM", "6:00 PM"};
		
		time = new JLabel("Time");
        time.setBounds(450,340,200,50);
		time.setFont(font5);
        panel.add(time);

		timeBox = new JComboBox(timeTable);
		timeBox.setSelectedIndex(-1);
		timeBox.setBounds(650,340,140,50);
		timeBox.setFont(font7);
		panel.add(timeBox);
		
		String[] classTable = {"Economy", "Business"};

		
		Choose_a_Class = new JLabel("Class");
        Choose_a_Class.setBounds(450,410,200,50);
		Choose_a_Class.setFont(font5);
        panel.add(Choose_a_Class);

		
		classBox = new JComboBox(classTable);
		classBox.setSelectedIndex(-1);
		classBox.setBounds(650,410,140,50);
		classBox.setFont(font7);
		panel.add(classBox);
		
		
		price = new JLabel("Price: " + ticketPirce);
        price.setBounds(850,410,180,50);
		price.setFont(font5);
        panel.add(price);
		
	

        buyBtn= new JButton("Purchase");
        buyBtn.setBounds(550,500,150,50);
		buyBtn.setFont(font3);
		buyBtn.setForeground(Color.WHITE);
		buyBtn.setBackground(btnColor);
        panel.add(buyBtn);


        resetBtn = new JButton("Reset");
        resetBtn.setBounds(760,500,150,50);
		resetBtn.setFont(font3);
		resetBtn.setForeground(Color.WHITE);
		resetBtn.setBackground(btnColor);
        panel.add(resetBtn);
		
		backBtn = new JButton("Back");
		backBtn.setBounds(655, 570, 150, 50);
		backBtn.setFont(font3);
		backBtn.setForeground(Color.WHITE);
		backBtn.setBackground(backBtnColor);
		panel.add(backBtn);
		
		
		
        this.add(panel);
		
		classBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selectedItem = (String) classBox.getSelectedItem();
                if(selectedItem == "Economy")
				{
					ticketPirce = "750";
					price.setText("Price: " + ticketPirce);
				}
				else if(selectedItem == "Business")
				{
					ticketPirce = "1750";
					price.setText("Price: " + ticketPirce);
				}
            }
        });
		
		
		dateTF.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                if (dateTF.getText().equals("DD/MM/YY")) {
                    dateTF.setText("");
                }
            }

            public void focusLost(FocusEvent e) {
                if (dateTF.getText().isEmpty()) {
                    dateTF.setText("DD/MM/YY");
                }
            }
        });
		
		buyBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				String ticketdate = dateTF.getText();
				String ticketTime = (String) timeBox.getSelectedItem();
				
				String startDes = (String) des1.getSelectedItem();
				String endDes = (String) des2.getSelectedItem();
				
				String className = (String) classBox.getSelectedItem();
				
				try
				{
					
					
				
				
					if(!ticketdate.isEmpty()  && ticketTime != null && startDes != null && endDes != null && className != null)
					{
						
						int currentBalanceInt = Integer.parseInt(currentBalance);
						int ticketPirceInt = Integer.parseInt(ticketPirce);

						if(ticketPirceInt <= currentBalanceInt)
						{

							BufferedWriter fileW = new BufferedWriter(new FileWriter(balanceFile));
							fileW.close();
							
							fileW = new BufferedWriter(new FileWriter(balanceFile,true));
							
							int amount = Integer.parseInt(currentBalance) - Integer.parseInt(ticketPirce);

							fileW.write(amount + "\n");
							
							fileW.close();

							Random random = new Random();
							int code = random.nextInt(9000) + 1000;						
													

							BufferedWriter file = new BufferedWriter(new FileWriter(ticketFile,true));
							file.write(ticketdate + "," + ticketTime + "," + startDes + "," + endDes + "," + className + "," + code + "\n");

							file.close();
							
								
							JOptionPane.showMessageDialog(null, "Purchased SuccessFully.", "Success!",
											JOptionPane.INFORMATION_MESSAGE);
											
											
							balanceLabel.setText("Current Balance : " + amount);
							price.setText("Price: 0");


							dateTF.setText("DD/MM/YY");
							des1.setSelectedIndex(-1);
							des2.setSelectedIndex(-1);
							
							timeBox.setSelectedIndex(-1);
							classBox.setSelectedIndex(-1);
							
						}
						else
						{
							JOptionPane.showMessageDialog(null, "Insufficient Balance!", "Warning!",
							JOptionPane.WARNING_MESSAGE);
						}
							
										
						
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Please fill all of the fields.", "Warning!",
									JOptionPane.WARNING_MESSAGE);
					}
			
			
				}
				
				catch(IOException ioe)
				{
					ioe.printStackTrace();
				}
				
		
			}
        });
		
		
		resetBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
					dateTF.setText("DD/MM/YY");
					des1.setSelectedIndex(-1);
					des2.setSelectedIndex(-1);
					
					timeBox.setSelectedIndex(-1);
					classBox.setSelectedIndex(-1);

			}
		});
		
		backBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
					setVisible(false);
					Home home = new Home(user);
					home.setVisible(true);

			}
		});





    }

}