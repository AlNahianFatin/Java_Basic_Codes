package Classes;

import Classes.*;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;


public class BuyTickets extends Tickets
{
	private UserAccount user;

	
    public BuyTickets(UserAccount user)
    {
        super(user);
        
    }

}