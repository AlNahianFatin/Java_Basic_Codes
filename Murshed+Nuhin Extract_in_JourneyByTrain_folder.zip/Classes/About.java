package Classes;

import Classes.*;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;


public class About extends JFrame
{


    private JPanel panel;
	private ImageIcon bgImage;
	private JLabel bgLabel;

    private JButton backBtn;

	private Color color1, bgColor, btnColor;
	private Font font1,font2,font3,font4,font5,font6,font7;




    public About()
    {
        super("Profile");
        this.setSize(1080,720);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        panel= new JPanel();
        panel.setLayout(null);
		panel.setBackground(bgColor);

		// Colors
		color1 = new Color(194,47,37);
		bgColor = new Color(251,251,251);
		btnColor = new Color(36,138,192);


		// Fonts
        font1 = new Font("Segoe UI Black", Font.BOLD, 40);
        font2 = new Font("Segoe UI Black", Font.PLAIN, 25);
        font3 = new Font("Segoe UI Black", Font.PLAIN, 20);
        font4 = new Font("Segoe UI Semibold", Font.PLAIN, 35);
        font5 = new Font("Segoe UI Black", Font.BOLD, 25);
        font6 = new Font("Segoe UI", Font.PLAIN, 22);
        font7 = new Font("Segoe UI", Font.PLAIN, 18);


        backBtn = new JButton("Back");
        backBtn.setBounds(465,600,150,50);
		backBtn.setFont(font3);
		backBtn.setForeground(Color.WHITE);
		backBtn.setBackground(btnColor);
        panel.add(backBtn);


		bgImage = new ImageIcon("E:/JavaCodes/JourneyByTrain/Images/us.jpg");
		bgLabel = new JLabel(bgImage);
		bgLabel.setBounds(0, 0, 1080, 720);
		panel.add(bgLabel);

        this.add(panel);




		backBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				setVisible(false);
				Welcome welcomeFrame = new Welcome();
				welcomeFrame.setVisible(true);

			}
		});


    }

}