package Classes;

import Classes.*;

import java.lang.*;
import java.util.*;
import java.io.*;

public class UserAccount
{
	private static String userName;
	private String userEmail;
	private String userPass;
	public String ticketFile;
	public String balanceFile;
	public String currentBalance;
	
	
	private File file; 
	private FileWriter filewriter;
	private Scanner fileScanner;
	
	public UserAccount(){}
	
	public UserAccount(String userName,String userPass)
	{
		this.userName = userName;
		this.userPass = userPass;
	}
	
	public UserAccount(String userName,String userEmail ,String userPass)
	{
		this.userName = userName;
		this.userEmail = userEmail;
		this.userPass = userPass;
	}
	public void setUserName(String userName)
	{
		this.userName = userName;
	}
	
	public void setUserEmail(String userEmail)
	{
		this.userEmail = userEmail;
	}
	
	public void setUserPass(String userPass)
	{
		this.userPass = userPass;
	}
	
	public String getUserName()
	{
		return userName;
	}
	
	public String getUserEmail()
	{
		return userEmail;
	}
	
	public String getUserPass()
	{
		return userPass;
	}
	
	public String getTicketFile()
	{
		return ticketFile;
	}

	
	public String getBalanceFile()
	{
		return balanceFile;
	}
	
	public String getCurrentBalance()
	{
		try
		{
			BufferedReader fileR = new BufferedReader(new FileReader(balanceFile));
			String line;
			
		

			if((line = fileR.readLine()) != null) {
				currentBalance = line;
			}
			else
			{
				currentBalance = "0"; 
			}

			fileR.close();
		}
		
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
		return currentBalance;
	}
	
	
	
	
	public void addAccount()
	{
		try
		{
		file=new File("./users.txt");
		file.createNewFile();
		
		filewriter=new FileWriter(file,true);
		
		filewriter.write(getUserName()+ "," + getUserEmail() + "," + getUserPass() + "\n");
		
		filewriter.flush();
		filewriter.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
		
	}
	
	public boolean hasAccount(String userName,String userPass)
	{
		boolean hasAccount = false;
		
		file = new File("./users.txt");
		
		try{
			
		fileScanner = new Scanner(file);
		
			while(fileScanner.hasNextLine())
			{
				String line = fileScanner.nextLine();
				
				String[] value = line.split(",");
				
				if(value[0].equals(userName)&&value[2].equals(userPass))
				{
					hasAccount = true;
					this.userName = value[0];
					this.userEmail = value[1];
					this.userPass = value[2];
					this.ticketFile = value[0] + "'sTickets.txt";
					this.balanceFile = value[0] + "'sBalance.txt";

				}
			}
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
		return hasAccount;
		
	}
	
	
}

