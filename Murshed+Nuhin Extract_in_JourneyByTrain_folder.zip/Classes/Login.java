package Classes;

import Classes.*;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class Login extends JFrame
{
	private ImageIcon bgImage, logo;
	private JLabel logoLabel, titleLabel, userLabel, passLabel, bgLabel;
	private JButton loginBtn, signUpBtn, backBtn;
	private JTextField userTF;
	private JPasswordField passPF;
	private JPanel panel;
	
	private Color color1, bgColor, btnColor,backBtnColor;
	private Font font1,font2,font3,font4,font5,font6,font7;

	
	public Login()
	{
		super("Login");
		this.setSize(1080, 720);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(bgColor);	
		
		// Colors
		color1 = new Color(194,47,37);
		bgColor = new Color(251,251,251);
		btnColor = new Color(36,138,192);
		backBtnColor = new Color(189,1,1);


		// Fonts
        font1 = new Font("Segoe UI Black", Font.BOLD, 50);
        font2 = new Font("Segoe UI Black", Font.PLAIN, 25);
        font3 = new Font("Segoe UI Black", Font.PLAIN, 20);
        font4 = new Font("Segoe UI Semibold", Font.PLAIN, 35);
        font5 = new Font("Segoe UI Black", Font.BOLD, 30);
        font6 = new Font("Segoe UI", Font.PLAIN, 22);
        font7 = new Font("Segoe UI", Font.PLAIN, 18);

		
		titleLabel = new JLabel("User Login");
		titleLabel.setBounds(620, 80, 360, 100);
		titleLabel.setFont(font1);
		panel.add(titleLabel);
		
		userLabel = new JLabel("User Name : ");
		userLabel.setBounds(470, 250, 200, 50);
		userLabel.setFont(font5);
		panel.add(userLabel);
		
		userTF = new JTextField();
		userTF.setBounds(710, 250, 280, 50);
		userTF.setFont(font6);
		panel.add(userTF);
		
		passLabel = new JLabel("Password   : ");
		passLabel.setBounds(470, 320, 200, 50);
		passLabel.setFont(font5);
		panel.add(passLabel);
		
		passPF = new JPasswordField();
		passPF.setBounds(710, 320, 280, 50);
		passPF.setFont(font6);
		passPF.setEchoChar('#');
		panel.add(passPF);
		
		loginBtn = new JButton("Login");
		loginBtn.setBounds(580, 420, 130, 50);
		loginBtn.setFont(font3);
		loginBtn.setForeground(Color.WHITE);
		loginBtn.setBackground(btnColor);
		panel.add(loginBtn);
		
		signUpBtn = new JButton("Sign up");
		signUpBtn.setBounds(780, 420, 130, 50);
		signUpBtn.setFont(font3);
		signUpBtn.setForeground(Color.WHITE);
		signUpBtn.setBackground(btnColor);
		panel.add(signUpBtn);
		
		backBtn = new JButton("Back");
		backBtn.setBounds(680, 490, 130, 50);
		backBtn.setFont(font3);
		backBtn.setForeground(Color.WHITE);
		backBtn.setBackground(backBtnColor);
		panel.add(backBtn);
		
			
		bgImage = new ImageIcon("E:/JavaCodes/JourneyByTrain/Images/loginBg.jpg");
		bgLabel = new JLabel("",bgImage,JLabel.CENTER);
		bgLabel.setBounds(0, 0, 1080, 720);
		panel.add(bgLabel);
		
		this.add(panel);
		
		
		loginBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String userName = userTF.getText();
				String userPass = passPF.getText();
				
				if(userName.isEmpty() || userPass.isEmpty())
				{
					JOptionPane.showMessageDialog(null, "Please fill all of the fields.", "Warning!",
								JOptionPane.WARNING_MESSAGE);
				}
				else 
				{
					UserAccount user = new UserAccount(userName,userPass);
					if(user.hasAccount(userName,userPass))
					{
						
						JOptionPane.showMessageDialog(null, "Login SuccessFully.", "Success!",
								JOptionPane.INFORMATION_MESSAGE);
									
						setVisible(false);
						Home home = new Home(user);
						home.setVisible(true);
					}
					else
					{
					
						JOptionPane.showMessageDialog(null, "Invalid username or password.", "Warning!",
									JOptionPane.WARNING_MESSAGE);
					}
				}
				
			}
        });
		
		signUpBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				SignUp signUpFrame = new SignUp();
				signUpFrame.setVisible(true);
			}
        });	
		
		backBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				Welcome welcomeFrame = new Welcome();
				welcomeFrame.setVisible(true);
			}
        });
		
	}
}