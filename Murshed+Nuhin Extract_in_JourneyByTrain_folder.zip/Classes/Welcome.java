package Classes;

import Classes.*;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class Welcome extends JFrame
{
	private ImageIcon logo;
	private JLabel logoLabel, titleLabel1, titleLabel2;
	private JButton aboutUsBtn, exitBtn, signUpBtn, loginBtn;
	private JPanel panel;
	private Color bgColor, btnColor, exitBtnColor, color1;
	private Font font1,font2,font3,font4,font5,font6,font7;
	
	public Welcome()
	{
		super("Journey By Train");
		this.setSize(820, 550);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(bgColor);
		
		// Colors
		color1 = new Color(194,47,37);
		bgColor = new Color(251,251,251);
		btnColor = new Color(36,138,192);
		exitBtnColor = new Color(189,1,1);


		// Fonts
        font1 = new Font("Segoe UI Black", Font.BOLD, 50);
        font2 = new Font("Segoe UI Black", Font.PLAIN, 25);
        font3 = new Font("Segoe UI Black", Font.PLAIN, 25);
        font4 = new Font("Segoe UI Semibold", Font.PLAIN, 35);
        font5 = new Font("Segoe UI Black", Font.BOLD, 30);
        font6 = new Font("Segoe UI", Font.PLAIN, 22);
        font7 = new Font("Segoe UI", Font.PLAIN, 18);

		
	
		
		logo= new ImageIcon("E:/JavaCodes/JourneyByTrain/Images/logo.png");
		logoLabel = new JLabel(logo);
		logoLabel.setBounds(20, 0, 300, 550);
		panel.add(logoLabel);
		
		titleLabel1 = new JLabel("Journy by");
		titleLabel1.setBounds(425, 50, 600, 100);
		titleLabel1.setFont(font1);
		panel.add(titleLabel1);
		
		titleLabel2 = new JLabel("Train");
		titleLabel2.setBounds(475, 115, 600, 100);
		titleLabel2.setFont(font1);
		panel.add(titleLabel2);
		
		loginBtn = new JButton("Login");
		loginBtn.setBounds(360, 280, 180, 70);
		loginBtn.setFont(font5);
		loginBtn.setForeground(Color.WHITE);
		loginBtn.setBackground(btnColor);
		panel.add(loginBtn);
		
		aboutUsBtn = new JButton("About Us");
		aboutUsBtn.setBounds(360, 380, 180, 70);
		aboutUsBtn.setFont(font5);
		aboutUsBtn.setForeground(Color.WHITE);
		aboutUsBtn.setBackground(btnColor);
		panel.add(aboutUsBtn);
		
		signUpBtn = new JButton("Sign up");
		signUpBtn.setBounds(580, 280, 180, 70);
		signUpBtn.setFont(font5);
		signUpBtn.setForeground(Color.WHITE);
		signUpBtn.setBackground(btnColor);
		panel.add(signUpBtn);
		
		exitBtn = new JButton("Exit");
		exitBtn.setBounds(580, 380, 180, 70);
		exitBtn.setFont(font5);
		exitBtn.setForeground(Color.WHITE);
		exitBtn.setBackground(exitBtnColor);
		panel.add(exitBtn);
		
		
		
		this.add(panel);
		
		loginBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				Login loginFrame = new Login();
				loginFrame.setVisible(true);
			}
        });
		
		signUpBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				SignUp signUpFrame = new SignUp();
				signUpFrame.setVisible(true);
			}
        });
		
		aboutUsBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				About about = new About();
				about.setVisible(true);
			}
        });
		
		
		exitBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
        });
		
	}
}