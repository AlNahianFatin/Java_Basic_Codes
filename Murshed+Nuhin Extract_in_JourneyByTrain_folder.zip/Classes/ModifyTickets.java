package Classes;

import Classes.*;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class ModifyTickets extends Tickets {
	
		private UserAccount user;
		private JButton upgradeBtn;  
		private String modifingTicketCode;
		private String previousClass;


    public ModifyTickets(UserAccount user) {
        super(user);
		
		upgradeBtn= new JButton("Upgrade");
        upgradeBtn.setBounds(550,500,150,50);
		upgradeBtn.setFont(font3);
		upgradeBtn.setForeground(Color.WHITE);
		upgradeBtn.setBackground(btnColor);
        panel.add(upgradeBtn);
		
		bgImage = new ImageIcon("E:/JavaCodes/JourneyByTrain/Images/upgrade.png");
		bgLabel.setIcon(bgImage);
		
		
		title.setText("Change Ticket Details");

        setTitle("Upgrde Tickets");
		
		panel.remove(buyBtn);
		
		upgradeBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String ticketdate = dateTF.getText();
				String ticketTime = (String) timeBox.getSelectedItem();
				
				String startDes = (String) des1.getSelectedItem();
				String endDes = (String) des2.getSelectedItem();
				
				String className = (String) classBox.getSelectedItem();

				try
				{
					
					
					
					BufferedReader fileR = new BufferedReader(new FileReader(ticketFile));
					String line;
					
					int totalTickets = 0;

					while ((line = fileR.readLine()) != null) {
						totalTickets++;
					}

					fileR.close();
					
					fileR = new BufferedReader(new FileReader(ticketFile));

					String[] oldTickets = new String[totalTickets];
					
					int j = 0;

					while ((line = fileR.readLine()) != null) {
						
						boolean insert = false;
						while(insert == false) {
						
							String[] value = line.split(",");
					
							String dateStr = value[0];
							String timeStr = value[1];
							String fromStr = value[2];
							String toStr = value[3];
							String classStr = value[4];
							String codeStr = value[5];
							
							oldTickets[j++] = dateStr + "," + timeStr + "," + fromStr + "," + toStr + "," + classStr + "," + codeStr;
						
							insert = true;
						}

					}

					fileR.close();
						
						
					BufferedWriter fileW = new BufferedWriter(new FileWriter(ticketFile, false));
					
					fileW.write("");
					fileW.close();

					fileW = new BufferedWriter(new FileWriter(ticketFile));
					
					if(!ticketdate.isEmpty() && ticketTime != null && startDes != null && endDes != null && className != null)
					{
						fileW.write(ticketdate + "," + ticketTime + "," + startDes + "," + endDes + "," + className + "," + modifingTicketCode + "\n");
					}

					for(int i = 0 ; i < totalTickets; i++)
					{
						String[] value = oldTickets[i].split(",");
						String savedTicketCode = value[5];

						if(modifingTicketCode.trim().equals(savedTicketCode.trim()))
						{
							previousClass = value[4];
						}
						else
						{
							System.out.println("In");
							fileW.write(value[0]+ "," + value[1] + "," + value[2] + "," + value[3] + "," + value[4] + "," + value[5] + "\n");
						}
					}

					fileW.close();

					
					if(!className.trim().equals(previousClass.trim()))
					{
						int currentBalanceInt = Integer.parseInt(currentBalance);
						int ticketPirceInt = Integer.parseInt(ticketPirce);
						
					
						if(previousClass.trim().equals("Business") && className.trim().equals("Economy"))
						{
							BufferedWriter fileBW = new BufferedWriter(new FileWriter(balanceFile));
							fileBW.close();
							
							fileBW = new BufferedWriter(new FileWriter(balanceFile,true));
							
							int amount = currentBalanceInt + 1000;

							fileBW.write(amount + "\n");
							
							fileBW.close();
						}
						else if(previousClass.trim().equals("Economy") && className.trim().equals("Business"))
						{
							if(ticketPirceInt <= currentBalanceInt)
							{
								BufferedWriter fileBW = new BufferedWriter(new FileWriter(balanceFile));
								fileBW.close();
								
								fileBW = new BufferedWriter(new FileWriter(balanceFile,true));
								
								int amount = currentBalanceInt - 1000;

								fileBW.write(amount + "\n");
								
								fileBW.close();
							}
							else
							{
								JOptionPane.showMessageDialog(null, "Insufficient Balance!", "Warning!",
								JOptionPane.WARNING_MESSAGE);
							}
						}
					}
						
					
					JOptionPane.showMessageDialog(null, "Updated SuccessFully.", "Success!",
										JOptionPane.INFORMATION_MESSAGE);
										
					setVisible(false);
					Home home = new Home(user);
					home.setVisible(true);
					
										
				
				}

				catch(IOException ioe)
				{
					ioe.printStackTrace();
				}






			}
        });
    }
	
	public void loadTicketsInfo(String ticketCode)
	{
		try
		{

		this.modifingTicketCode = ticketCode;
		

		BufferedReader fileR = new BufferedReader(new FileReader(ticketFile));
			String line;

			boolean readOnce = false;

				while ((line = fileR.readLine()) != null) {


						String[] value = line.split(",");
						String savedTicketCode = value[5];

						if(ticketCode.equals(savedTicketCode))
						{
							String dateStr = value[0];
							String timeStr = value[1];
							String fromStr = value[2];
							String toStr = value[3];
							String clssStr = value[4];

							dateTF.setText(dateStr);
							des1.setSelectedItem(fromStr);
							des2.setSelectedItem(toStr);
							timeBox.setSelectedItem(timeStr);
							classBox.setSelectedItem(clssStr);

						}
	
				}

		}

		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	
	
}
