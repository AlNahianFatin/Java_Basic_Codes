package Classes;

import Classes.*;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class Balance extends JFrame
{
	private UserAccount user;

	private String balanceFile;
	private String currentBalance;

    private JPanel panel;
    private ImageIcon bgImg, masterCard, visaCard;
    private JLabel title, bgLabel, masterCardLabel, visaCardLabel, cBalanceLabel, cardNo, cardHolder, cvv, expaireDate, amount;
    private JTextField cardNoTF, cardHolderTF, expaireDateTF, amountTF ;
	private JPasswordField cvvPF;
    private JButton confirmBtn, backBtn;

	private Color color1, bgColor, btnColor,backBtnColor;
	private Font font1,font2,font3,font4,font5,font6,font7;


	public Balance(){}
    public Balance(UserAccount user)
    {
        super("Balance");
        this.setSize(1080,720);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		

        panel= new JPanel();
        panel.setLayout(null);
		panel.setBackground(bgColor);
		
		this.user = user;
		balanceFile = user.getBalanceFile();
		currentBalance = user.getCurrentBalance();

		// Colors
		color1 = new Color(194,47,37);
		bgColor = new Color(251,251,251);
		btnColor = new Color(36,138,192);
		backBtnColor = new Color(189,1,1);


		// Fonts
        font1 = new Font("Segoe UI Black", Font.BOLD, 40);
        font2 = new Font("Segoe UI Black", Font.PLAIN, 25);
        font3 = new Font("Segoe UI Black", Font.PLAIN, 20);
        font4 = new Font("Segoe UI Semibold", Font.PLAIN, 35);
        font5 = new Font("Segoe UI Black", Font.BOLD, 25);
        font6 = new Font("Segoe UI", Font.PLAIN, 22);
        font7 = new Font("Segoe UI", Font.PLAIN, 18);



        title = new JLabel("Add Balance");
        title.setBounds(440,30,400,100);
		title.setFont(font1);
        panel.add(title);


        bgImg= new ImageIcon("E:/JavaCodes/JourneyByTrain/Images/balance.PNG");
        bgLabel = new JLabel(bgImg);
        bgLabel.setBounds(15,40,400,500);
        panel.add(bgLabel);

		cBalanceLabel = new JLabel("Current Balance : " + currentBalance);
        cBalanceLabel.setBounds(70,530,400,100);
		cBalanceLabel.setFont(font5);
        panel.add(cBalanceLabel);


        masterCard= new ImageIcon("E:/JavaCodes/JourneyByTrain/Images/masterCard.PNG");
        masterCardLabel = new JLabel(masterCard);
        masterCardLabel.setBounds(600,150,80,70);
        panel.add(masterCardLabel);


        visaCard= new ImageIcon("E:/JavaCodes/JourneyByTrain/Images/visaCard.PNG");
        visaCardLabel = new JLabel(visaCard);
        visaCardLabel.setBounds(700,150,80,70);
        panel.add(visaCardLabel);


        cardNo = new JLabel("Card Number");
        cardNo.setBounds(500,260,200,50);
		cardNo.setFont(font5);
        panel.add(cardNo);

		cardNoTF = new JTextField();
        cardNoTF.setBounds(700,260,220,50);
		cardNoTF.setFont(font6);
        panel.add(cardNoTF);


        cardHolder= new JLabel("Holder Name");
        cardHolder.setBounds(500,330,200,50);
		cardHolder.setFont(font5);
        panel.add(cardHolder);

		cardHolderTF= new JTextField();
        cardHolderTF.setBounds(700,330,220,50);
		cardHolderTF.setFont(font6);
        panel.add(cardHolderTF);


        cvv = new JLabel("CVV");
        cvv.setBounds(500,400,100,50);
		cvv.setFont(font5);
        panel.add(cvv);

		cvvPF = new JPasswordField();
        cvvPF.setBounds(580,400,100,50);
		cvvPF.setFont(font6);
        panel.add(cvvPF);


        expaireDate = new JLabel("MM/YY");
        expaireDate.setBounds(700,400,100,50);
		expaireDate.setFont(font5);
        panel.add(expaireDate);

		expaireDateTF = new JTextField();
        expaireDateTF.setBounds(820,400,100,50);
		expaireDateTF.setFont(font6);
        panel.add(expaireDateTF);

        amount = new JLabel("Amount");
        amount.setBounds(500,470,200,50);
		amount.setFont(font5);
        panel.add(amount);

        amountTF = new JTextField();
        amountTF.setBounds(700,470,220,50);
		amountTF.setFont(font6);
        panel.add(amountTF);



        confirmBtn= new JButton("Confirm");
        confirmBtn.setBounds(520,570,160,50);
		confirmBtn.setFont(font3);
		confirmBtn.setForeground(Color.WHITE);
		confirmBtn.setBackground(btnColor);
        panel.add(confirmBtn);

        backBtn= new JButton("Back");
        backBtn.setBounds(700,570,160,50);
		backBtn.setFont(font3);
		backBtn.setForeground(Color.WHITE);
		backBtn.setBackground(backBtnColor);
        panel.add(backBtn);





       

		confirmBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String cardNoValue = cardNoTF.getText();
				String cardHolderValue = cardHolderTF.getText();
				String expaireDateValue = expaireDateTF.getText();
				String cvvValue = cvvPF.getText();
				String amountValue = amountTF.getText();
				
				
				try
				{
					if(cardNoValue.isEmpty() || cardHolderValue.isEmpty() || expaireDateValue.isEmpty() || cvvValue.isEmpty() || amountValue.isEmpty())
					{
						
						JOptionPane.showMessageDialog(null, "Please fill all of the fields.", "Warning!",
							JOptionPane.WARNING_MESSAGE);
							
					}
					else
					{
						
						BufferedWriter fileW = new BufferedWriter(new FileWriter(balanceFile));
						fileW.close();
						
						fileW = new BufferedWriter(new FileWriter(balanceFile,true));
						
						int amount = Integer.parseInt(currentBalance) + Integer.parseInt(amountValue);

						fileW.write(amount + "\n");
						
						fileW.close();
						
							
						JOptionPane.showMessageDialog(null, "Add SuccessFully.", "Success!",
										JOptionPane.INFORMATION_MESSAGE);
										
						cardNoTF.setText("");
						cardHolderTF.setText("");
						expaireDateTF.setText("");
						cvvPF.setText("");
						amountTF.setText("");
						
						setVisible(false);
						Balance balance = new Balance(user);
						balance.setVisible(true);
					}
				
					
			
			
				}
				
				catch(IOException ioe)
				{
					ioe.printStackTrace();
				}
				
			}
		});

		backBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				setVisible(false);
				Home home = new Home(user);
				home.setVisible(true);

			}
		});

	 this.add(panel);
    }


}