package Classes;

import Classes.*;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;


public class Profile extends JFrame
{
	private UserAccount user;
	private String userName;
	private String userEmail;
	private String userPass;
	
	

    private JPanel panel;
    private ImageIcon profileImg;
    private JLabel profile, profileImgLabel, name, email, pass, nPass, cPass ;
    private JTextField emailTF ;
    private JPasswordField passPF, nPassPF, cPassPF;
    private JButton saveBtn, backBtn;
	
	private Color color1, bgColor, btnColor;
	private Font font1,font2,font3,font4,font5,font6,font7;



	public Profile(){}
    public Profile(UserAccount user)
    {
        super("Profile");
        this.setSize(1080,720);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		

        panel= new JPanel();
        panel.setLayout(null);
		panel.setBackground(bgColor);
		
		this.user = user;
		userName = user.getUserName();
		userEmail = user.getUserEmail();
		userPass = user.getUserPass();
		
		// Colors
		color1 = new Color(194,47,37);
		bgColor = new Color(251,251,251);
		btnColor = new Color(36,138,192);


		// Fonts
        font1 = new Font("Segoe UI Black", Font.BOLD, 40);
        font2 = new Font("Segoe UI Black", Font.PLAIN, 25);
        font3 = new Font("Segoe UI Black", Font.PLAIN, 20);
        font4 = new Font("Segoe UI Semibold", Font.PLAIN, 35);
        font5 = new Font("Segoe UI Black", Font.BOLD, 25);
        font6 = new Font("Segoe UI", Font.PLAIN, 22);
        font7 = new Font("Segoe UI", Font.PLAIN, 18);



        profile= new JLabel("Profile");
        profile.setBounds(550,20,250,50);
		profile.setFont(font1);
        panel.add(profile);


        profileImg= new ImageIcon("E:/JavaCodes/JourneyByTrain/Images/profile.PNG");
        profileImgLabel = new JLabel(profileImg);
        profileImgLabel.setBounds(15,100,400,450);
        panel.add(profileImgLabel);




		name = new JLabel("Welcome " + userName);
		name.setBounds(500, 110, 600, 50);
		name.setFont(font4);
		name.setForeground(color1);
		panel.add(name);

        email = new JLabel("Email");
        email.setBounds(450,210,250,50);
		email.setFont(font5);
        panel.add(email);


        pass = new JLabel("Current Password");
        pass.setBounds(450,280,250,50);
		pass.setFont(font5);
        panel.add(pass);


        nPass = new JLabel("New Password");
        nPass.setBounds(450,350,250,50);
		nPass.setFont(font5);
        panel.add(nPass);

        cPass = new JLabel("Confirm Password");
        cPass.setBounds(450,420,250,50);
		cPass.setFont(font5);
        panel.add(cPass);



        emailTF = new JTextField();
        emailTF.setBounds(750,210,200,50);
		emailTF.setFont(font7);
        panel.add(emailTF);


        passPF = new JPasswordField();
        passPF.setBounds(750,280,200,50);
		passPF.setFont(font7);
		passPF.setEchoChar('#');
        panel.add(passPF);


        nPassPF = new JPasswordField();
        nPassPF.setBounds(750,350,200,50);
		nPassPF.setFont(font7);
		nPassPF.setEchoChar('#');
        panel.add(nPassPF);

        cPassPF = new JPasswordField();
        cPassPF.setBounds(750,420,200,50);
		cPassPF.setFont(font7);
		cPassPF.setEchoChar('#');
        panel.add(cPassPF);
		
		
		
		saveBtn= new JButton("Save");
        saveBtn.setBounds(530,530,150,50);
		saveBtn.setFont(font3);
		saveBtn.setForeground(Color.WHITE);
		saveBtn.setBackground(btnColor);
        panel.add(saveBtn);


        backBtn = new JButton("Back");
        backBtn.setBounds(740,530,150,50);
		backBtn.setFont(font3);
		backBtn.setForeground(Color.WHITE);
		backBtn.setBackground(btnColor);
        panel.add(backBtn);


		loadInfo();

        this.add(panel);



        saveBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			
				String email = emailTF.getText();
				String pass = passPF.getText();
				String nPass= nPassPF.getText();
				String cPass = cPassPF.getText();
				
				userPass = user.getUserPass();



				if(email.isEmpty() || pass.isEmpty() || nPass.isEmpty() || cPass.isEmpty() )
				{
					JOptionPane.showMessageDialog(null, "Please fill all of the fields.", "Warning!",
								JOptionPane.WARNING_MESSAGE);
				}
				else
				{
					if(userPass.equals(pass))
					{
						if(nPass.equals(cPass))
						{
							try
							{
								
							
								
								BufferedReader fileR = new BufferedReader(new FileReader("users.txt"));
								String line;
								
								int totalUsers = 0;

								while ((line = fileR.readLine()) != null) {
									totalUsers++;
								}

								fileR.close();
								
								fileR = new BufferedReader(new FileReader("users.txt"));



								UserAccount[] oldUsers = new UserAccount[totalUsers];

								int lineCount = 0;

								while ((line = fileR.readLine()) != null) {
									
										String[] value = line.split(",");
										String uName = value[0];
										String uEmail = value[1];
										String uPass = value[2];

										oldUsers[lineCount] = new UserAccount(uName, uEmail, uPass);

										lineCount++;

								}

								fileR.close();
									
									
								BufferedWriter fileW = new BufferedWriter(new FileWriter("users.txt"));
								
								fileW.close();
								
								fileW = new BufferedWriter(new FileWriter("users.txt",true));
								
								fileW.write(userName+ "," + email + "," + cPass + "\n");
								
								fileW.close();
								
								

								
								
								
								fileW = new BufferedWriter(new FileWriter("users.txt",true));
								
								
								for(int i = 0 ; i < totalUsers; i++)
								{
									if(userPass.equals(oldUsers[i].getUserPass()) && userEmail.equals(oldUsers[i].getUserEmail()))
									{
										oldUsers[i] = null;
									}
								}
								
								for(int i = 0 ; i < totalUsers; i++)
								{
									if(oldUsers[i] != null)
									{
										fileW.write(oldUsers[i].getUserName()+ "," + oldUsers[i].getUserEmail()+ "," + oldUsers[i].getUserPass() + "\n");

									}
								}
								
									fileW.close();
									
									
								user.setUserName(userName);
								user.setUserEmail(email);
								user.setUserPass(cPass);
								
								passPF.setText("");
								nPassPF.setText("");
								cPassPF.setText("");
								
								JOptionPane.showMessageDialog(null, "Update SuccessFully.", "Success!",
													JOptionPane.INFORMATION_MESSAGE);
													
							
								
							
							}

							catch(IOException ioe)
							{
								ioe.printStackTrace();
							}
						}
						else
						{
							JOptionPane.showMessageDialog(null, "Confirm Password not matching!", "Warning!",
								JOptionPane.WARNING_MESSAGE);
						}
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Current Password not matching!", "Warning!",
							JOptionPane.WARNING_MESSAGE);
					}
					
					

                }
            }
        });
		
		backBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				setVisible(false);
				Home home = new Home(user);
				home.setVisible(true);

			}
		});


    }
	
	public void loadInfo()
	{
			emailTF.setText(userEmail);
	}

}