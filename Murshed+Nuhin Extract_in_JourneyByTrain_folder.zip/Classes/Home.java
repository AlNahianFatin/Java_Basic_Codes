package Classes;

import Classes.*;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class Home extends JFrame
{
	private UserAccount user;
	
	private String userName;
	private String ticketFile;
	
	private boolean hasTickets = false;
	
	private ImageIcon bgImage;
	private JLabel titleLabel, routineLabel, emptyLabel, bgLabel;
	private JButton profileBtn, buyTicketsBtn, balanceBtn, exitBtn;

	private JPanel panel;
	private JComboBox menu;

	private Color color1, bgColor, btnColor, exitBtnColor;
	private Font font1,font2,font3,font4,font5,font6;

	private JScrollPane scrollPane;

	public Home(){}
	public Home(UserAccount user)
	{
		
		super("Home");
		this.setSize(1080, 720);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(bgColor);
		
		this.user = user;
		userName = user.getUserName();
		ticketFile = user.getTicketFile();


		// Colors
		color1 = new Color(194,47,37);
		bgColor = new Color(251,251,251);
		btnColor = new Color(36,138,192);
		exitBtnColor = new Color(189,1,1);

		// Fonts
        font1 = new Font("Segoe UI Black", Font.BOLD, 40);
        font2 = new Font("Segoe UI Black", Font.PLAIN, 25);
        font3 = new Font("Segoe UI Black", Font.PLAIN, 20);
        font4 = new Font("Segoe UI Semibold", Font.PLAIN, 35);
        font5 = new Font("Segoe UI", Font.PLAIN, 30);
        font6 = new Font("Segoe UI", Font.PLAIN, 22);
       
		
		titleLabel = new JLabel("Welcome " + userName);
		titleLabel.setBounds(400, 20, 600, 50);
		titleLabel.setFont(font1);
		panel.add(titleLabel);

		/*String[] options = {  "Profile", "Courses", "CGPA", "Consulting", "Library", "Balance" };*/
		
		profileBtn = new JButton("Profile");
		profileBtn.setBounds(40, 210, 160, 50);
		profileBtn.setFont(font3);
		profileBtn.setForeground(Color.WHITE);
		profileBtn.setBackground(btnColor);
		panel.add(profileBtn);
		
		buyTicketsBtn = new JButton("Buy Tickets");
		buyTicketsBtn.setBounds(40, 280, 160, 50);
		buyTicketsBtn.setFont(font3);
		buyTicketsBtn.setForeground(Color.WHITE);
		buyTicketsBtn.setBackground(btnColor);
		panel.add(buyTicketsBtn);
		
		
		balanceBtn = new JButton("Balance");
		balanceBtn.setBounds(40, 350, 160, 50);
		balanceBtn.setFont(font3);
		balanceBtn.setForeground(Color.WHITE);
		balanceBtn.setBackground(btnColor);
		panel.add(balanceBtn);
		
		exitBtn = new JButton("Exit");
		exitBtn.setBounds(40, 420, 160, 50);
		exitBtn.setFont(font3);
		exitBtn.setForeground(Color.WHITE);
		exitBtn.setBackground(exitBtnColor);
		panel.add(exitBtn);
		
	
		
		profileBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					
				setVisible(false);
				Profile profile = new Profile(user);
				profile.setVisible(true);

			}
        });
		
		buyTicketsBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
					setVisible(false);
					BuyTickets ticketsPanel = new BuyTickets(user);
					ticketsPanel.setVisible(true);

			}
        });
		
		
		balanceBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					
				setVisible(false);
				Balance balance = new Balance(user);
				balance.setVisible(true);

			}
        });
		
	
		exitBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
        });
		
		

		getTicketsData();

	


		bgImage = new ImageIcon("E:/JavaCodes/JourneyByTrain/Images/homebg.jpg");
		bgLabel = new JLabel("",bgImage,JLabel.CENTER);
		bgLabel.setBounds(0, 0, 1080, 720);
		//bgLabel.setBounds(720, 0, 300, 720);
		panel.add(bgLabel);


		this.add(panel);

	}







	public void getTicketsData()
	{
			this.userName = userName;
			

		 try {

			BufferedReader file = new BufferedReader(new FileReader(ticketFile));
			String line;

			if((line = file.readLine()) != null)
			{
				hasTickets = true;
				file.close();

				file = new BufferedReader(new FileReader(ticketFile));

				int totalTickets = 0;

				while ((line = file.readLine()) != null) {
						totalTickets += 5;
				}

				file.close();
				file = new BufferedReader(new FileReader(ticketFile));
				
				System.out.println(totalTickets);
				String[] list = new String[totalTickets];
				
				int i = 0;
				
				while ((line = file.readLine()) != null) {

					String[] ticketData = line.split(",");
					
					boolean insert = false;
					while(insert == false) {
						String[] value = line.split(",");

						list[i++] = "";
						
						list[i++] = "          Date: " + value[0] + "     -     " + "Time: " + value[1];
						
						list[i++] = "          From: " + value[2] + "     -     " + "To: " + value[3];
						
						list[i++] = "          Class: " + value[4] + "     -     " + "Code: " + value[5];
						
						list[i++] = " -------------------------------------------------------";
						
						insert = true;
					}

				}
						

				file.close();


		
				JList<String> ticketList = new JList<>(list);

				ticketList.setBackground(Color.WHITE);
				ticketList.setFont(font2);
				ticketList.setFixedCellHeight(30); 

				JScrollPane scrollPane = new JScrollPane(ticketList);


				scrollPane.setBounds(300, 120, 600, 460);

				panel.add(scrollPane);

				ticketList.addMouseListener(new MouseAdapter() {
					public void mouseClicked(MouseEvent e) {
					   if (e.getClickCount() == 1) {
							String selectedItem = ticketList.getSelectedValue();
							String ticketCode = selectedItem.substring(selectedItem.length() - 4);


							if(selectedItem.contains("Code"))
							{
								setVisible(false);
								ModifyTickets modifyTickets = new ModifyTickets(user);
								modifyTickets.loadTicketsInfo(ticketCode);
								modifyTickets.setVisible(true);

							}
						}
					}
				});


			}
			else 
			{
				hasTickets = false;
				emptyLabel = new JLabel("No Ticket Purchased!",JLabel.CENTER);
				emptyLabel.setBounds(260, 100, 600, 500);
				emptyLabel.setBackground(color1);
				emptyLabel.setForeground(color1);
				emptyLabel.setFont(font1);
				panel.add(emptyLabel);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}



}

